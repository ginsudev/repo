//
//  GSCore.h
//  GSCore
//
//  Created by Noah Little on 16/4/2023.
//

#ifndef GSCore_h
#define GSCore_h

#import <Foundation/Foundation.h>

#endif /* GSCore_h */
