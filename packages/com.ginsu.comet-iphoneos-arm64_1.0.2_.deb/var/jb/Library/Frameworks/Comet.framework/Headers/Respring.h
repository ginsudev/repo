//
//  Respring.h
//  Comet
//
//  Created by Noah Little on 26/3/2023.
//

#import <Foundation/Foundation.h>

@interface Respring : NSObject
+ (void)execute;
@end
