#import <Foundation/Foundation.h>
#import "Respring.h"

FOUNDATION_EXPORT double CometVersionNumber;
FOUNDATION_EXPORT const unsigned char CometVersionString[];
