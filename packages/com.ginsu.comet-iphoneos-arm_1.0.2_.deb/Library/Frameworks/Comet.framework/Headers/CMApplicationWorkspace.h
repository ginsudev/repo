//
//  CMApplicationWorkspace.h
//  Comet
//
//  Created by Noah Little on 9/4/2023.
//

#ifndef CMApplicationWorkspace_h
#define CMApplicationWorkspace_h

@interface CMApplicationWorkspace : NSObject
- (NSArray<NSDictionary *> *)allApplications;
@end

#endif /* CMApplicationWorkspace_h */
